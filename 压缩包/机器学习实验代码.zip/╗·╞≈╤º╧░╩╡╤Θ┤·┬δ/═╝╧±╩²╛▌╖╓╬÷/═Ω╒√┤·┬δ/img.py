import sys
import cv2
import numpy as np

# Load input image -- 'table.jpg'
input_file = 'D:/ml/flower.jpg'
img = cv2.imread(input_file)
print(img.reshape(1,-1))

input_file2 = 'D:/ml/flower.jpg'
img2 = cv2.imread(input_file2)
print(img2-img)