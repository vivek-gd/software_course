import sys

import cv2
import numpy as np

# Load input image -- 'table.jpg'
input_file = 'D:/ml/flower.jpg'
img = cv2.imread(input_file)
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

star = cv2.xfeatures2d.StarDetector_create()
keypoints = star.detect(img_gray, None)

img_sift = np.copy(img)
cv2.drawKeypoints(img, keypoints, img_sift, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

cv2.imshow('Input image', img)
cv2.imshow('STAR features', img_sift)
cv2.waitKey()