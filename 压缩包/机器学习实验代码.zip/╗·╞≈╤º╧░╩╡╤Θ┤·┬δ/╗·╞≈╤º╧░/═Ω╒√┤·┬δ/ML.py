from sklearn import datasets
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn import metrics
import numpy as np
from sklearn.model_selection import cross_val_score

#分别加载iris和digits数据集
boston = datasets.load_boston()
data = boston.data
target = boston.target
reg = linear_model.LinearRegression()
X_train,X_test,y_train,y_test=train_test_split(data,target,test_size=0.4,random_state=0)
reg.fit(X_train,y_train)
y_pred=reg.predict(X_test)
print(metrics.mean_squared_error(y_test, y_pred))
scores = cross_val_score(reg, data, target, cv=5,scoring='neg_mean_squared_error')
print(scores)