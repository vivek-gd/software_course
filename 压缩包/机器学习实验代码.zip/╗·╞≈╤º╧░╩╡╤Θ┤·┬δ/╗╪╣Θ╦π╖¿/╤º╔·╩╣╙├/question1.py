﻿import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn import linear_model
from sklearn.preprocessing import PolynomialFeatures
if __name__ == "__main__":
    
    ###STEP1###
    #加载数据并进行分割
    data = datasets.load_boston()
    x = data.data
    y = data.target
    x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=1)
   
    
    ###STEP2###
    #创建线性回归模型并进行训练
    linear_model = LinearRegression()
    linear_model.fit(x_train,y_train)
    #问题一：创建多项式回归模型并进行训练
	"""
	在
	这
	里
	补
	充
	代
	码
	"""
    
    
    ###STEP3###
    #使用模型进行预测并计算mse
    y_predict=linear_model.predict(x_test)
    x_test1=model.fit_transform(x_test)
    y_hat = poly_linear_model.predict(x_test1)
    linear_mse = np.average((y_predict - np.array(y_test)) ** 2)
    poly_mse = np.average((y_hat - np.array(y_test)) ** 2)  # Mean Squared Error
    print (linear_mse,poly_mse)
    