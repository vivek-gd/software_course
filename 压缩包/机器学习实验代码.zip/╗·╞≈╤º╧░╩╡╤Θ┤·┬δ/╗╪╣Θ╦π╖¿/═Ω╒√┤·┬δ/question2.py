﻿import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV
from sklearn import datasets

if __name__ == "__main__":
    
    ###STEP1###
    #加载数据并进行分割
    data = datasets.load_boston()
    x = data.data
    y = data.target
    x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=1)
    
    
    ###STEP2###
    #创建Lasso回归模型
    model = Ridge()
    alpha_can = np.logspace(-3, 1, 10)
    
    
    ###STEP3###
    #问题一：创建参数优化器GridSearchCV，将参数model，param_grid传入
    ridge_model = GridSearchCV(model, param_grid={'alpha': alpha_can})
    ridge_model.fit(x, y)
    print ('验证参数：\n', ridge_model.best_params_)
    
    
    ###STEP4###
    #使用最优参数的Lasso模型进行预测
    y_hat = ridge_model.predict(x_test)
    mse = np.average((y_hat - np.array(y_test)) ** 2)  # Mean Squared Error
    rmse = np.sqrt(mse)  # Root Mean Squared Error
    print (mse, rmse)
    #从图像中观察预测值是否准确
    t = np.arange(len(x_test))
    plt.plot(t, y_test, 'r-', linewidth=2, label='Test')
    plt.plot(t, y_hat, 'g-', linewidth=2, label='Predict')
    plt.legend(loc='upper right')
    plt.grid()
    plt.show()
