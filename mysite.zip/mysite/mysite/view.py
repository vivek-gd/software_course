from django.shortcuts import render
import pymysql


def show_student(request):
    db = pymysql.connect("localhost", "root", "password", "test", port=3306, cursorclass = pymysql.cursors.DictCursor)
    cursor = db.cursor()
    ctx = {}
    if request.POST:
        name = request.POST['name']
        sql = "select * from student where name like %s"
        cursor.execute(sql, ['%'+name+'%'])
    else:
        sql = "select * from student"
        cursor.execute(sql)
    data = cursor.fetchall()
    context = {}
    context['students'] = data
    return render(request, 'student.html', context)


def addStudent(request):

    return render(request, 'addStudent.html')


def modifyStudent(request, id):

    return render(request, 'modifyStudent.html')
